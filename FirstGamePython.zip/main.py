#setup
yes_no = ["yes", "no", "."]
Citizens = ['the old lady', "."]
Second_Citizens = ["the scientist", "."]
Places = ["the river", "."]
SusBoi = ["walk up to him", "."]
HelpingDaBoi = ["help", "help him", "."]
town2shop = ["head to the shop", "go to the shop", "."]
shop = ["spear", "nothing", "cheek trap", ".", "nothing"]
EndOfTutorial = ["explore", "."]
dev_code = 0





print("never capitolize your text. \nyou will not get a correct response.")

print('you have just woken up.')
print('you are in a town called Saint Pual')
player_name = input("What's your name? ")
if player_name == "Chayton Gorostiza":
    print("hello, Developer")
    dev_code = 1
elif player_name == "jolan":
  print("LOL here take this special item. I won't tell you what it is.")
elif player_name == "jacob":
  print("LOL you need some help so take a fish")
  fish = 1
print(f"your name is {player_name}")
print("You wake up in a town. There are townsfolk everywhere. nobody\nseems to notice you, as if it were normal.")
response = ""
while response not in yes_no:
    response = input("Would you like to talk to the townsfolk?\n")
    if response == "yes":
        print("")
    elif response == "no":
        quit()
    else:
        print('huh?')
response = ""
while response not in Citizens:
    response = input("There is a Scientist \nand an old lady, who would you like to talk too? \n")
    if response == "the scientist":
        print('He says, You are not needed here, go away. I am busy.\n')
      
    elif response == "the old lady":
        print("My son hasn't returned for dinner, and I don't know where he is.\ncan you find him?\n")
        if player_name == "jolan":
          print("He said he was looking for a special item.\n")
    else:
        print("I didn't get that")
response = ""
while response not in Second_Citizens:
    response = input("There is a Scientist, And an old lady.\nwho else would you like to talk too? \n")
    if response == "the scientist":
        print("Oh yeah, I've seen him. He ran down to the river last time he \nwas here to get me some water")
    elif response == "the old lady":
       print ("I've already told you what I needed")
    else:
       print("Just answer the question")
response = ""
while response not in Places:
    response = input("Where would you like to go? \nso far you know about saint pual and the river .\n")
    if response == "the river":
      print("you see a boy down by the river, holding  something")
    elif response == "saint pual":
      print("you're already here")
    else:
      print("Your only options are the river and saint pual. ")
response = ""
while response not in  SusBoi:
    response = input("You can either ask him who he is or walk up to him \n")
    if response == "walk up to him":
      print("you walk up to him and notice that he is\ncarring rocks in a pail. ") 
    elif response == "ask him who he is":
      print("he turns around and looks at you, only to start putting rocks in his pail once again.")
    else:
      print("")
response = ""
while response not in  HelpingDaBoi:
    response = input("you should probably help him \n")
    if response == "help":
      print("you go over to the boy and start helping him gather rocks.\nHe explains that the scientist wanted him to collect rocks\nso he could study them for fossils.\n")
      rock = 1
      pail = 1
    elif response == "help him":
      print("\nyou go over to the boy and start helping him gather rocks.\nHe explains that the scientist wanted him to collect rocks\nso he could study them for fossils.\n")
      rock = 1
      pail = 1
    else:
      print("huh?")
response = ""
while response not in town2shop:
  response = input("you go to town and tell the lady about her son, and she is thankful. she gives you a handful of coins and \ntells you about the shop.\n")
  if response == "head to the shop":
    print("You go to the shop")
    coins = 5
  elif response == "go to the shop":
    print("you go to the shop")
    coins = 5
  else:
    coins = 5



#shop 



response = ""
while response not in shop:
  response = input("in the shop there is…\na spear/3\na strange key/10\na cheek trap/2\nwhen buying items, only type the item name\n")
  if response == "spear" and coins > 3:
    print("you have now bought the spear")
    spear = 1
    coins = coins-3
  elif response == "strange key":
    print("you do not have enough coins for that. you have " , coins, "coins.")
  elif response == "cheek trap" and coins > 2:
    print("you have now bought a cheek trap.")
    cheek_trap = 1
    coins = coins-2
  elif response == "nothing":
    print("you decide not to buy anything.")
  elif response == "spear" and coins < 3:
    print("You do not have enough coins for that.")
  elif response == "cheek trap" and coins < 2:
    print("I'm sorry, you don't have enough coins for that.")
#end of tutorial
print("loading")
if dev_code == 1:
  coins = 1000000
response = ""
while response not in EndOfTutorial:
  response = input("that is the end of the tutorial. You can now venture off \nand explore, go to the shop, or\n you can stay and chat to the townsfolk.\n")
  if response == "explore":
    print("you go exploring and have now discovered a new land mark. The Forest. you can hunt here and you can explore from here")
  elif response == "talk to the old lady":
    print("you go over to the old lady to find her watering her flowers in her garden. She does not need you right now.")
  elif response == "talk to the scientist":
    print("Oh, I see you got some rocks too. Here, take this. The scientist gives you a water bottle in exchange for the pail and rocks the boy gave you.")
    water_bottle = 1
    pail = 0
    rock = 0
  elif response == "go to the shop":
    while response not in shop:
      response = input("in the shop there is…\na spear/3\na strange key/10\na cheek trap/2\nwhen buying items, only type the item name\n")
      if response == "spear" and coins > 3:
          print("you bought the spear")
          spear = 1
          coins = coins-3
      elif response == "cheek trap" and coins > 2:
          print("you bought a cheek trap.")
          cheek_trap = 1
          coins = coins-2
      elif response == "strange key" and coins > 10:
        print("you bought the strange key")
        strange_key = 1
      elif response == "nothing":
          print("you decide not to buy anything.")
      elif response == "spear" and coins < 3:
          print("You do not have enough coins for that.")
      elif response == "cheek trap" and coins < 2:
          print("I'm sorry, you don't have enough coins for that.")
      elif response == "strange key" and coins < 10:
          print("you do not have enough coins for that. you have " , coins, "coins.")
if strange_key == 1:
  print("ah, yes. \nThe developer. \nThis key was not intended to be used this early. \nYou are the chosen one. \nGo now, find a better game. \nthis game is very small and the chosen one needs bigger, \nbetter games to acheive the great goals ahead of them. \ngoodbye now.")
  quit()